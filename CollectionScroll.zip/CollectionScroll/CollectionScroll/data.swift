//
//  data.swift
//  CollectionScroll
//
//  Created by Intern on 04/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import Foundation

class data {
    
    var categories = ["Chinese New Year","Buffets","Mini Buffets"]
    var dishname1 = ["Chinese1","Chinese2","Chinese3","Chinese4","Chinese5","Chinese6"]
    var dishname2 = ["Buffets1","Buffets2","Buffets3","Buffets4","Buffets5","Buffets6"]
    var dishname3 = ["Mini1","Mini2","Mini3","Mini4","Mini5","Mini6"]
    
    var dish1label = ["44.52Km - chinese","44.52Km - chinese","44.52Km - chinese","44.52Km - chinese","44.52Km - chinese","44.52Km - chinese"]
    var dish2label = ["44.52Km - Buffets","44.52Km - Buffets","44.52Km - Buffets","44.52Km - Buffets","44.52Km - Buffets","44.52Km - Buffets"]
    var dish3label = ["44.52Km - MiniBuff","44.52Km - MiniBuff","44.52Km - MiniBuff","44.52Km - MiniBuff","44.52Km - MiniBuff","44.52Km - MiniBuff"]
    
    var dish1Price = ["Minimum order: $10.00","Minimum order: $20.00","Minimum order: $30.00","Minimum order: $40.00","Minimum order: $50.00","Minimum order: $60.00"]
    var dish2price = ["Minimum order: $10.00","Minimum order: $20.00","Minimum order: $30.00","Minimum order: $40.00","Minimum order: $50.00","Minimum order: $60.00"]
    var dish3price = ["Minimum order: $10.00","Minimum order: $20.00","Minimum order: $30.00","Minimum order: $40.00","Minimum order: $50.00","Minimum order: $60.00"]
}
