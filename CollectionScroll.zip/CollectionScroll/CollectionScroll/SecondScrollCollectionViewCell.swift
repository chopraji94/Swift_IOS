//
//  SecondScrollCollectionViewCell.swift
//  CollectionScroll
//
//  Created by Intern on 03/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class SecondScrollCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var secondImageView: UIImageView!
    
}
