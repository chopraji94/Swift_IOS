//
//  ScrollCollectionViewCell.swift
//  CollectionScroll
//
//  Created by Intern on 03/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ScrollCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var cellLbl: UILabel!
    @IBOutlet weak var firstImageView: UIImageView!
    @IBOutlet weak var redView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
