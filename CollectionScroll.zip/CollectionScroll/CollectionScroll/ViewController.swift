//
//  ViewController.swift
//  CollectionScroll
//
//  Created by Intern on 03/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

enum categories {
    case chinese
    case buffets
    case miniBuffets
}

enum horizontalDishes {
    case pic1
    case pic2
    case pic3
    case pic4
    case pic5
    case pic6
    case pic7
    case pic8
    case pic9
    case pic10
}

enum verticalDishes {
    case picl1
    case picl2
    case picl3
    case picl4
    case picl5
    case picl6
}

class ViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    
    @IBOutlet weak var secondCollectionView: UICollectionView!
    
    
    @IBOutlet weak var thirdCollectionView: UICollectionView!
    
    @IBOutlet weak var labelInView: UILabel!
    
    
    var user:data? = data()
    var takinItemArray = [String]()
    var takingDistanceArray = [String]()
    var takingpriceArray = [String]()
    var row:[categories] = [.chinese, .buffets, .miniBuffets]
    var bollForLine = ["true","false","false"]
    var images:[horizontalDishes] = [.pic1, .pic2, .pic3, .pic4, .pic5, .pic6, .pic7, .pic8, .pic9, .pic10]
    var imageLabel:[verticalDishes] = [.picl1, .picl2, .picl3, .picl4, .picl5, .picl6]
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        
        secondCollectionView.delegate = self
        secondCollectionView.dataSource = self
        
        thirdCollectionView.delegate = self
        thirdCollectionView.dataSource = self
        
        labelInView.text = "Chinese"
        takinItemArray = user!.dishname1
        takingDistanceArray = user!.dish1label
        takingpriceArray = user!.dish1Price
        // Do any additional setup after loading the view.
    }

}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.collectionView {
            return row.count
        }
        if collectionView == self.secondCollectionView {
            return images.count
        }
        return imageLabel.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        if collectionView == self.collectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)  as? ScrollCollectionViewCell
            switch row[indexPath.row] {
            case .chinese:
                cell?.cellLbl.text = "Chinese"
                cell?.firstImageView.image = UIImage(named: "Image")
                cell?.backgroundColor = UIColor.lightGray
                if self.bollForLine[0] == "true" {
                    cell?.redView.isHidden = false
                }
                else {
                    cell?.redView.isHidden = true
                }
                return cell!
            case .buffets:
                cell?.cellLbl.text = "Buffets"
                cell?.firstImageView.image = UIImage(named: "Image-1")
                cell?.backgroundColor = UIColor.lightGray
                if self.bollForLine[1] == "true" {
                    cell?.redView.isHidden = false
                }
                else {
                    cell?.redView.isHidden = true
                }
                return cell!
            case .miniBuffets:
                cell?.cellLbl.text = "Mini Buffets"
                cell?.firstImageView.image = UIImage(named: "Image-2")
                if self.bollForLine[2] == "true" {
                    cell?.redView.isHidden = false
                }
                else {
                    cell?.redView.isHidden = true
                }
                cell?.backgroundColor = UIColor.lightGray
                return cell!
            }
            
        }
        if collectionView == self.secondCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)  as? SecondScrollCollectionViewCell
            switch images[indexPath.row] {
            case .pic1:
                cell?.secondImageView.image = UIImage(named: "Image-3")
            case .pic2:
                cell?.secondImageView.image = UIImage(named: "Image-4")
            case .pic3:
                cell?.secondImageView.image = UIImage(named: "Image-5")
            case .pic4:
                cell?.secondImageView.image = UIImage(named: "Image-6")
            case .pic5:
                cell?.secondImageView.image = UIImage(named: "Image-7")
            case .pic6:
                cell?.secondImageView.image = UIImage(named: "Image-8")
            case .pic7:
                cell?.secondImageView.image = UIImage(named: "Image-9")
            case .pic8:
                cell?.secondImageView.image = UIImage(named: "Image-10")
            case .pic9:
                cell?.secondImageView.image = UIImage(named: "Image-11")
            case .pic10:
                cell?.secondImageView.image = UIImage(named: "Image-12")
            }
            return cell!
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)  as? ThirdCollectionViewCell
            switch imageLabel[indexPath.row] {
            case .picl1:
                cell?.thirdViewImage.image = UIImage(named: "Image-3")
                cell?.thirdLbl1.text = takinItemArray[0]
                cell?.thirdlbl2.text = takingDistanceArray[0]
                cell?.thirdlbl3.text = takingpriceArray[0]
            case .picl2:
                cell?.thirdViewImage.image = UIImage(named: "Image-9")
                cell?.thirdLbl1.text = takinItemArray[1]
                 cell?.thirdlbl2.text = takingDistanceArray[1]
                 cell?.thirdlbl3.text = takingpriceArray[1]
            case .picl3:
                cell?.thirdViewImage.image = UIImage(named: "Image-5")
                cell?.thirdLbl1.text = takinItemArray[2]
                 cell?.thirdlbl2.text = takingDistanceArray[2]
                 cell?.thirdlbl3.text = takingpriceArray[2]
            case .picl4:
                cell?.thirdViewImage.image = UIImage(named: "Image-6")
                cell?.thirdLbl1.text = takinItemArray[3]
                 cell?.thirdlbl2.text = takingDistanceArray[3]
                 cell?.thirdlbl3.text = takingpriceArray[3]
            case .picl5:
                cell?.thirdViewImage.image = UIImage(named: "Image-7")
                cell?.thirdLbl1.text = takinItemArray[4]
                 cell?.thirdlbl2.text = takingDistanceArray[4]
                 cell?.thirdlbl3.text = takingpriceArray[4]
            case .picl6:
                cell?.thirdViewImage.image = UIImage(named: "Image-8")
                cell?.thirdLbl1.text = takinItemArray[5]
                 cell?.thirdlbl2.text = takingDistanceArray[5]
                 cell?.thirdlbl3.text = takingpriceArray[5]
        }
        return cell!
        
    }
    }
    
        
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.collectionView {
        switch row[indexPath.row] {
            case .chinese:
                labelInView.text = user?.categories[0]
                takinItemArray = user!.dishname1
                takingDistanceArray = user!.dish1label
                takingpriceArray = user!.dish1Price
                self.bollForLine[0] = "true"
                self.bollForLine[1] = "false"
                self.bollForLine[2] = "false"
                self.thirdCollectionView.reloadData()
            case .buffets:
                labelInView.text = user?.categories[1]
                takinItemArray = user!.dishname2
                 takingDistanceArray = user!.dish2label
                takingpriceArray = user!.dish2price
                self.bollForLine[0] = "false"
                self.bollForLine[1] = "true"
                self.bollForLine[2] = "false"
                self.thirdCollectionView.reloadData()
            case .miniBuffets:
                labelInView.text = user?.categories[2]
                takinItemArray = user!.dishname3
                 takingDistanceArray = user!.dish3label
                takingpriceArray = user!.dish3price
                self.bollForLine[0] = "false"
                self.bollForLine[1] = "false"
                self.bollForLine[2] = "true"
                self.thirdCollectionView.reloadData()
            }
            self.collectionView.reloadData()
        }
    }
    
    
    
}
