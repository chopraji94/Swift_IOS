//
//  ThirdCollectionViewCell.swift
//  CollectionScroll
//
//  Created by Intern on 04/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ThirdCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var thirdViewImage: UIImageView!
    
    @IBOutlet weak var thirdLbl1: UILabel!
    
    @IBOutlet weak var thirdlbl2: UILabel!
    
    @IBOutlet weak var thirdlbl3: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
