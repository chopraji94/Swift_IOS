//
//  ViewController.swift
//  APIHit
//
//  Created by Intern on 14/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        apiHit()
        
    }
    
    func apiHit( ) {
        
        let urlStrng = "https://api.musixmatch.com/ws/1.1/track.search?apikey=90eadb301b159741822c93efb2e8b3b3&q_lyrics=say%20my%20name"
        let url: URL = URL(string: urlStrng)!
        let session = URLSession(configuration: URLSessionConfiguration.default)
        
        let task = session.dataTask(with: url) { (data: Data?, urlResponse: URLResponse?, error: Error?) in
            
            print(data)
            
                    guard let jsonResponse = try?JSONSerialization.jsonObject(with: data!, options: .mutableContainers) else {
                        return
                    }
            print("1---------> \(jsonResponse)")

            guard let dict = jsonResponse as? [String: Any] else {
                return
            }
            print("2---------> \(dict)")
//
//
            guard let meta = dict["message"] as? [String: Any] else {
                return
            }
             print("3---------> \(meta)")
            
            guard let body = meta["body"] as? [String: Any] else {
                return
            }
            print("4---------> \(body)")
            

            guard let trackList = body["track_list"] as? [[String: Any]] else {
                return
            }
            print("5---------> \(trackList)")
            
            guard let track = trackList[0] as? [String: Any] else {
                return
            }
            print("6---------> \(track)")

        }
        
        task.resume()
        
        
        
    }
    
}





//class DataParsing {
//
//    class func jsonWith(data: Data) -> Any? {
//        guard let jsonResponse = try?JSONSerialization.jsonObject(with: data, options: .mutableContainers) else {
//            return nil
//        }
//        return jsonResponse
//    }
//}
