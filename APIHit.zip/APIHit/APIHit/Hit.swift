////
////  Hit.swift
////  APIHit
////
////  Created by Intern on 14/05/19.
////  Copyright © 2019 Intern. All rights reserved.
////
//
//import Foundation
//
//class APIManager {
//    
//    func executeAPI(url: String ,  callback: @escaping (_ data: [String: Any]?, _ error: Error?) -> Void) {
//        
////        let url = URL(string: url)!
////        let session = URLSession(configuration: .default)
////
////        let task = session.dataTask(with: url) { (data: Data?, response: URLResponse?, error: Error?) in
////            if let errorIs = error {
////                callback(nil, errorIs)
////                return
////            }
////
////            guard let jsonResponse = DataParsing.jsonWith(data: data!) as? [String: Any] else {
////                return
////            }
////
////            callback(jsonResponse, nil)
////
////        }
////
////        task.resume()
//        
//    }
//    
//}
//
//class DataParsing {
//    
//    class func jsonWith(data: Data) -> Any? {
//        
//        guard let jsonResponse = try?JSONSerialization.jsonObject(with: data, options: .mutableContainers) else {
//            return nil
//        }
//        return jsonResponse
//    }
//}
//
////class ShowDetails {
////    
////    var name: String = ""
////    
////    init(with dict: [String: Any]) {
////        if let value = dict["name"] as? String {
////            self.name = value
////        }
////        if let value = dict["code"] as? String {
////            self.name = value
////        }
////    }
////    
////    class func details(dictList: [[String: Any]]) -> [ShowDetails] {
////        let tempList = [ShowDetails]()
////        return tempList
////    }
////    class func getDetails(apiManager: APIManager, urlString: String, callback: @escaping (_ list: [ShowDetails]?, _ error: Error?) -> Void) {
////        
////        apiManager.executeAPI(url: urlString) { (response:  [String: Any]?, error: Error?) in
////            
////            guard let results = response!["results"] as? [String: [String: Any]] else {
////                callback(nil, nil)
////                return
////            }
////            
////            let detailList = ShowDetails.details(dictList: [results])
////            callback(detailList, nil)
////            
////            } as! ([String : Any]?, Error?) -> Void as! ([String : Any]?, Error?) -> Void
////    }
////}
////
