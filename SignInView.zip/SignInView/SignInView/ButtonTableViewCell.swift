//
//  ButtonTableViewCell.swift
//  SignInView
//
//  Created by Intern on 28/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ButtonTableViewCell: UITableViewCell {

   
    @IBOutlet weak var signUp: UIButton!
    var closure : (()-> Void)?
    var alert = UIAlertController()
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
    @IBAction func click(_ sender: Any) {
    closure!()

}
}
