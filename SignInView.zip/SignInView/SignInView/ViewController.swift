//
//  ViewController.swift
//  SignInView
//
//  Created by Intern on 28/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage
class ViewController: UIViewController {
    
    enum RowSelection : String {
        case fullName
        case phoneNo
        case email
        case password
        case confirmPassword
        case button
    }
    
    var pno:String?
    var picker : UIImagePickerController? = UIImagePickerController()
    var editButon = UIBarButtonItem()
    var alert = UIAlertController()
    var data = [String : Any]()
    var doneButon = UIBarButtonItem()
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var imgView: UIImageView!
    var profileImage : UIImage?
    var rowSelection : [RowSelection] = [.fullName, .phoneNo,.email,.password,.confirmPassword, .button]
    var enableUserInter: Bool! = true
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
        tableViewSelf()
        registerNib()
        alertView()
        print(data)
        editButton()
        getData()
        addGesture()
        
    
       
    }
    func addGesture(){
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapGestures))
        imgView.addGestureRecognizer(tapGesture)
        imgView.isUserInteractionEnabled = true
        picker?.delegate=self
    }
    
    @objc func tapGestures(gesture: UIGestureRecognizer) {
        let action:UIAlertController=UIAlertController(title: "Profile Picture Options", message: nil, preferredStyle: UIAlertController.Style.actionSheet)
        
        let gallaryAction = UIAlertAction(title: "Open Gallary", style: UIAlertAction.Style.default)
        {
            UIAlertAction in self.openGallary()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel)
        {
            UIAlertAction in self.cancel()
            
        }
        
        action.addAction(gallaryAction)
        action.addAction(cancelAction)
        
        
        self.present(action, animated: true, completion: nil)
    }
    
    func openGallary()
    {
        picker!.allowsEditing = false
        picker!.sourceType = UIImagePickerController.SourceType.photoLibrary
        self.present(picker!, animated: true, completion: nil)
    }
    
    
    func cancel(){
        print("Cancel Clicked")
    }
    
    
    func getData() {
        if let data = UserDefaults.standard.value(forKey: "data") as? [String: String] {
            self.data = data
            print(data)
            
            editButon.isEnabled = false
        } else {
            editButon.isEnabled = true
            
        }
    }
    
    
    func editButton(){
        editButon = UIBarButtonItem(barButtonSystemItem: .edit, target: self, action: #selector(edit))
        editButon.title = "Edit"
        self.navigationItem.rightBarButtonItem = editButon
        
        
    }
    
    @objc func edit() {
       self.enableUserInter = true
        
         tableView.reloadData()
    }
    
    func alertView(){
        alert = UIAlertController(title: "Do you want to save?".capitalized, message: nil, preferredStyle: .alert)
        let confirmAction = UIAlertAction(title: "Yes", style: UIAlertAction.Style.default) { (_) in
              self.editButon.isEnabled = true
            UserDefaults.standard.set(self.data, forKey: "data")
            self.enableUserInter = false
//            self.count = self.count - 1
            self.tableView.reloadData()
        }
        let denyAction = UIAlertAction(title: "No", style: UIAlertAction.Style.cancel) { (_) in
        }
        alert.addAction(confirmAction)
        alert.addAction(denyAction)
    }
    
    func registerNib(){
        let signNib = UINib(nibName: "SignInTableViewCell", bundle: nil)
        tableView.register(signNib, forCellReuseIdentifier: "SignInTableViewCell")
        
        let fieldNib = UINib(nibName: "FieldTableViewCell", bundle: nil)
        tableView.register(fieldNib, forCellReuseIdentifier: "FieldTableViewCell")
        
        let buttonNib = UINib(nibName: "ButtonTableViewCell", bundle: nil)
        tableView.register(buttonNib, forCellReuseIdentifier: "ButtonTableViewCell")
    }
    
    func tableViewSelf() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
    }
    
    fileprivate func showImagePickerController() {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
        self.present(imagePicker, animated: true, completion: nil)

    }

    
    
}
extension ViewController : UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.editButon.isEnabled == false {
            return  self.rowSelection.count
        }
        if self.enableUserInter {
            return self.rowSelection.count
        }
         return  self.rowSelection.count - 1
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch rowSelection[indexPath.row] {
            
        case .fullName:
            guard  let cell = tableView.dequeueReusableCell(withIdentifier: "SignInTableViewCell") as?SignInTableViewCell else {
                fatalError("Nib Not Load")
            }
            //            cell.fName.isUserInteractionEnabled = self.enableUserInter
            //            cell.lName.isUserInteractionEnabled = self.enableUserInter
            cell.fName.delegate = self
            cell.lName.delegate  = self
            cell.fName.isUserInteractionEnabled = self.enableUserInter
            cell.lName.isUserInteractionEnabled = self.enableUserInter
            cell.fName.placeholder = "First Name"
            cell.lName.placeholder = "Last Name"
            cell.fName.text = self.data["First Name"] as? String ?? ""
            cell.lName.text = self.data["Last Name"] as? String ?? ""
            cell.fName.tag = indexPath.row
            cell.lName.tag = indexPath.row
            cell.selectionStyle = .none
            return cell
            
        case .phoneNo:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "FieldTableViewCell") as? FieldTableViewCell else {
                fatalError("Nib Not Load")
            }
            cell.textField.delegate  = self
            cell.textField.isUserInteractionEnabled = self.enableUserInter
           
            cell.selectionStyle = .none
            cell.textField.placeholder = "Phone_no"
            //cell.textField.text = pno!
            cell.textField.text = self.data["Phone_no"] as? String ?? "asd"
            cell.textField.tag = indexPath.row
            return cell
            
        case .email:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "FieldTableViewCell") as? FieldTableViewCell else {
                fatalError("Nib Not Load")
            }
            cell.textField.delegate  = self
            cell.textField.isUserInteractionEnabled = self.enableUserInter
            
            cell.selectionStyle = .none
            cell.textField.placeholder = "email"
            cell.textField.text = self.data["email"] as? String ?? ""
            cell.textField.tag = indexPath.row
            return cell
            
        case .password:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "FieldTableViewCell") as? FieldTableViewCell else {
                fatalError("Nib Not Load")
            }
            cell.textField.delegate  = self
            cell.textField.isUserInteractionEnabled = self.enableUserInter
        
            cell.selectionStyle = .none
            cell.textField.placeholder = "pass"
                cell.textField.text = self.data["pass"] as? String ?? ""
            cell.textField.tag = indexPath.row
            return cell
            
        case .confirmPassword:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "FieldTableViewCell") as? FieldTableViewCell else {
                fatalError("Nib Not Load")
            }
            cell.textField.delegate  = self
            cell.textField.isUserInteractionEnabled = self.enableUserInter
            
            cell.selectionStyle = .none
            cell.textField.tag = indexPath.row
            cell.textField.placeholder = "confirmPass"
            cell.textField.text = self.data["confirmPass"] as? String ?? ""
            cell.textField.tag = indexPath.row
            return cell
            
        case .button:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "ButtonTableViewCell") as? ButtonTableViewCell else {
                fatalError("Nib Not Load")
            }
            cell.closure  = {
                    self.present(self.alert, animated: true)
            }
            cell.selectionStyle = .none
            return cell
        }
    }
    
    
}

extension ViewController : UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        print(textField.tag)
        
        switch rowSelection[textField.tag] {
        case .fullName:
            self.data["First Name"] = textField.text ?? ""
            self.data["Last Name"] = textField.text ?? ""
        case.phoneNo:
            self.data["Phone_no"] = textField.text ?? ""
           
        case.email:
            self.data["email"] = textField.text ?? ""
//                     print(self.data["Phone_no"])
        case.password:
            self.data["pass"] = textField.text ?? ""
        case.confirmPassword:
            self.data["confirmPass"] = textField.text ?? ""
        default:
            print("nil")
        }
        UserDefaults.standard.set(textField.text, forKey: textField.placeholder ?? "")
        print(data)
        

        
    }
}

extension ViewController : UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickImage = info[.originalImage] as? UIImage
        {   imgView.contentMode = .scaleAspectFit
            imgView.image = pickImage
        }
        self.tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}

