//
//  SignInTableViewCell.swift
//  SignInView
//
//  Created by Intern on 28/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class SignInTableViewCell: UITableViewCell {

    
    @IBOutlet weak var lName: UITextField!
    @IBOutlet weak var fName: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
