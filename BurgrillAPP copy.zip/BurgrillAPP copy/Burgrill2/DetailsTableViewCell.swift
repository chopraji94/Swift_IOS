//
//  DetailsTableViewCell.swift
//  Burgrill2
//
//  Created by Intern on 24/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class DetailsTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var itemLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var plusBtn: UIButton!
    
    @IBOutlet weak var minusBtn: UIButton!
    
    @IBOutlet weak var countLbl: UILabel!
    
    @IBOutlet weak var secondView: UIView!
    
    @IBOutlet weak var addBtn: UIButton!
    
    var number:Int = 0
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        countLbl.isHidden = true
        countLbl.text = "1"
        imageView?.image = #imageLiteral)
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    @IBAction func plusBtnAction(_ sender: Any) {
        number = number + 1
        countLbl.text = String(number)
        minusBtn.isEnabled = true
        
    }
    
    @IBAction func minusBtnAction(_ sender: Any) {
        if number == 0 {
            minusBtn.isEnabled = false
            secondView.isHidden = false
        }
        else {
            number = number - 1
            countLbl.text = String(number)
        }
    }
    
    @IBAction func addBtnAction(_ sender: Any) {
        secondView.isHidden = true
        countLbl.isHidden = false
    }
}
