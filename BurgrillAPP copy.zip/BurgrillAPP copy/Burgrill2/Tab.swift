//
//  Tab.swift
//  Burgrill2
//
//  Created by Intern on 24/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class Tab: UICollectionViewCell {
    
    
    @IBOutlet weak var textLbl: UILabel!
    
}
