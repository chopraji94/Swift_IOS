//
//  Details.swift
//  Burgrill2
//
//  Created by Intern on 24/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import Foundation

//class Details {
//
//    var products:String?
//}
//
//class Products {
//
//    var itemName:String?
//    var price:Int?
//    var imageURL:String?
//}
class Details {


    var dishname1 = ["Rec1","Rec2","Rec3","Rec4","Rec5"]
    var dishname2 = ["Meal1","Meal2","Meal3","Meal4","Meal5"]
    var dishname3 = ["Salad1","Salad2","Salad3","Salad4","Salad5"]
    var priceName1 = [21,22,23,24,25]
    var priceName2 = [11,12,13,14,15]
    var priceName3 = [31,32,33,34,35]
    var total = [115, 65, 165]
    var url1 = ["https://www.infoteech.com/wp-content/uploads/2019/01/What-is-URL.jpg","https://www.infoteech.com/wp-content/uploads/2019/01/What-is-URL.jpg","https://www.infoteech.com/wp-content/uploads/2019/01/What-is-URL.jpg","",""]


}


///


//
//var jsonData = [
//    
//    // Category 1
//                 ["catName": "Recommended",
//                  "catId": "",
//                  "products": [ ["productName": "Chicken",
//                                 "price": "11",
//                                 "image": "c1",
//                                 "id": "1"],
//                                
//                                ["productName": "Chicken1",
//                                 "price": "12",
//                                 "image": "c2",
//                                 "id": "2"],
//                                
//                                ["productName": "Chicken2",
//                                 "price": "13",
//                                 "image": "c3",
//                                 "id": "3"],
//                                
//                                ["productName": "Chicken3",
//                                 "price": "14",
//                                 "image": "c4",
//                                 "id": "4"],
//                                
//                                ["productName": "Chicken4",
//                                 "price": "15",
//                                 "image": "c5",
//                                 "id": "5"] ]],
//                 
//                 // Category 2
//
//                 ["catName": "Meals and Bowls",
//                  "catId": "",
//                  "products": [ ["productName": "Butter Chicken",
//                                 "price": "21",
//                                 "image": "B1",
//                                 "id": "1"],
//                                
//                                ["productName": "Butter Chicken1",
//                                 "price": "22",
//                                 "image": "B2",
//                                 "id": "2"],
//                                
//                                ["productName": "Butter Chicken2",
//                                 "price": "23",
//                                 "image": "B3",
//                                 "id": "3"],
//                                
//                                ["productName": "Butter Chicken3",
//                                 "price": "24",
//                                 "image": "B4",
//                                 "id": "4"],
//                                
//                                ["productName": "Butter Chicken4",
//                                 "price": "25",
//                                 "image": "B5",
//                                 "id": "5"] ]],
//                 
//                 
//                 // Category 3
//
//                 ["catName": "Salad",
//                  "catId": "",
//                  "products": [ ["productName": "ChickenSalad",
//                                 "price": "31",
//                                 "image": "A1",
//                                 "id": "1"],
//                                
//                                ["productName":  "ChickenSalad1",
//                                 "price": "32",
//                                 "image": "A2",
//                                 "id": "2"],
//                                
//                                ["productName": "ChickenSalad2",
//                                 "price": "33",
//                                 "image": "A3",
//                                 "id": "3"],
//                                
//                                ["productName": "ChickenSalad3",
//                                 "price": "34",
//                                 "image": "A4",
//                                 "id": "4"],
//                                
//                                ["productName": "ChickenSalad4",
//                                 "price": "35",
//                                 "image": "A5",
//                                 "id": "5"] ]],
                 
//
//                 // Category 4
//
//                 ["catName": "",
//                  "catId": "",
//                  "products": [ ["productName": "",
//                                 "price": "",
//                                 "image": "",
//                                 "id": ""],
//
//                                ["productName": "",
//                                 "price": "",
//                                 "image": "",
//                                 "id": ""] ]],
//
//                 // Category 5
//
//                 ["catName": "",
//                  "catId": "",
//                  "products": [ ["productName": "",
//                                 "price": "",
//                                 "image": "",
//                                 "id": ""],
//
//                                ["productName": "",
//                                 "price": "",
//                                 "image": "",
//                                 "id": ""] ]],
    
                 
//]
