//
//  ViewController.swift
//  Burgrill2
//
//  Created by Intern on 24/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit
enum Row {
    case recomended
    case meal
    case salad
}

enum Data {
    case meal0
    case meal1
    case meal2
    case meal3
    case meal4
}
class ViewController: UIViewController {

    @IBOutlet weak var totalLabel: UILabel!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var takingMenuLbl: UILabel!
    var rows:[Row] = [.recomended, .meal, .salad]
    var meals:[Data] = [.meal0, .meal1, .meal2, .meal3, .meal4]
    var total = 0
    
    var user:Details? = Details()
    var takingItemArray = [String]()
    var takingPriceArray = [Int]()
    var imageURL = [String]()
    var totalArray = [Int]()
    var amountArray = [Int]()
    var countVal = 0
    var clicked:Int = 0
    var recomendedVar:Int = 0
    var mealVar:Int = 0
    var saladVar:Int = 0
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        let headerNib = UINib(nibName: "DetailsTableViewCell" ,bundle: nil)
        tableView.register(headerNib, forCellReuseIdentifier: "headernib")
        imageURL = user!.url1
        print(imageURL)
        takingItemArray = user!.dishname1
        totalArray = user!.total
        takingPriceArray = user!.priceName1
    }

}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource  {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return rows.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
        switch rows[indexPath.row] {
        case .recomended :
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)  as? Tab
            cell!.textLbl.text = "Recommended"
            return cell!
        case .meal :
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)  as? Tab
            cell!.textLbl.text = "Meals and Bowls"
            return cell!
        case .salad :
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)  as? Tab
            cell!.textLbl.text = "Salad"
            return cell!
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var click = clicked
        if (click == 0 && recomendedVar == 0 && mealVar == 0 && saladVar == 0) || (click == 1 && recomendedVar == 0 && mealVar == 0 && saladVar == 0){
            
            switch rows[indexPath.row] {
            case .recomended :
                takingItemArray = user!.dishname1
                takingPriceArray = user!.priceName1
                takingMenuLbl.text = "Recomended"
                //totalLabel.text = "0"
                total = 0
                tableView.reloadData()
                clicked = 1
                recomendedVar = 1
                totalLabel.text = "0"
                print("click0")
            case .meal :
                takingItemArray = user!.dishname2
                takingPriceArray = user!.priceName2
                takingMenuLbl.text = "Meals And Bowls"
                //totalLabel.text = "0"
                total = 0
                tableView.reloadData()
                clicked = 1
                totalLabel.text = "0"
                mealVar = 1
                print("click0")
            case .salad :
                takingItemArray = user!.dishname3
                takingPriceArray = user!.priceName3
                takingMenuLbl.text = "Salad"
                //totalLabel.text = "0"
                total = 0
                tableView.reloadData()
                clicked = 1
                saladVar = 1
                totalLabel.text = "0"
                print("click0")
            }
        }
        else {
            clicked = 0
            switch rows[indexPath.row] {
            case .recomended :
                takingItemArray = user!.dishname1
                takingPriceArray = user!.priceName1
                takingMenuLbl.text = "Recomended Total"
                totalLabel.text = "0"
                tableView.reloadData()
                clicked = 0
                recomendedVar = 0 //recomeded
                print("click1")
                
            case .meal :
                takingItemArray = user!.dishname2
                takingPriceArray = user!.priceName2
                takingMenuLbl.text = "Meals And Bowls Total"
                totalLabel.text = "0"
                mealVar = 0 //meal
                tableView.reloadData()
                clicked = 0
            
                print("click1")
                
            case .salad :
                takingItemArray = user!.dishname3
                takingPriceArray = user!.priceName3
                takingMenuLbl.text = "Salad Total"
                totalLabel.text = "0"
                tableView.reloadData()
                saladVar = 0 //meal
                clicked = 0
                print("click1")
            }

        }

    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch meals[indexPath.row] {
        case .meal0:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? DetailsTableViewCell else {
                
                fatalError("Thumb Nail Table View Cell Not Found")
                
            }
            cell.selectionStyle = .none
            cell.itemLabel.text = takingItemArray[0]
            cell.priceLabel.text = "\(takingPriceArray[0])"
            total = total + ( takingPriceArray[0] * Int(cell.countLbl.text!)! )
            return cell
        case .meal1:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? DetailsTableViewCell else {
                
                fatalError("Thumb Nail Table View Cell Not Found")
                
            }
            cell.selectionStyle = .none
            cell.itemLabel.text = takingItemArray[1]
            cell.priceLabel.text = "\(takingPriceArray[1])"
            total = total + ( takingPriceArray[1] * Int(cell.countLbl.text!)! )
            return cell
        case .meal2:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? DetailsTableViewCell else {
                
                fatalError("Thumb Nail Table View Cell Not Found")
                
            }
            
            cell.selectionStyle = .none
            cell.itemLabel.text = takingItemArray[2]
            cell.priceLabel.text = "\(takingPriceArray[2])"
            total = total + ( takingPriceArray[2] * Int(cell.countLbl.text!)! )
            return cell
        case .meal3:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? DetailsTableViewCell else {
                
                fatalError("Thumb Nail Table View Cell Not Found")
                
            }
            cell.selectionStyle = .none
            cell.itemLabel.text = takingItemArray[3]
            cell.priceLabel.text = "\(takingPriceArray[3])"
            total = total + ( takingPriceArray[3] * Int(cell.countLbl.text!)! )
            return cell
        case .meal4:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? DetailsTableViewCell else {
                
                fatalError("Thumb Nail Table View Cell Not Found")
                
            }
            cell.selectionStyle = .none
            cell.itemLabel.text = takingItemArray[4]
            cell.priceLabel.text = "\(takingPriceArray[4])"
            total = total + ( takingPriceArray[4] * Int(cell.countLbl.text!)! )
            totalLabel.text = "\(total)"
            return cell
        }
   }
}
