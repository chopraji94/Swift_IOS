//
//  ViewController.swift
//  colapsabeltable
//
//  Created by Intern on 09/07/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

enum sectionHas {
    case pickup
    case deliver
}

enum rowHas {
    case address
    case email
}

class ViewController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    let inSection : [sectionHas] = [.pickup, .deliver]  
    let inRow:[rowHas] = [.address,.email]
    var boolCheck1:Bool = true
    var boolCheck2:Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
        let headerNib = UINib(nibName: "HeaderTableViewCell" ,bundle: nil)
        tableview.register(headerNib, forCellReuseIdentifier: "headernib")
        
        let cellsNib = UINib(nibName: "FieldsTableViewCell" ,bundle: nil)
        tableview.register(cellsNib, forCellReuseIdentifier: "cellsnib")
        tableview.separatorStyle = .none

    }

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return inSection.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch inSection[section] {
        case .pickup:
            if boolCheck1 {
                return inRow.count
            } else {
                return 0
            }
        case .deliver:
            if boolCheck2 {
                return inRow.count
            } else {
                return 0
            }
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerCell: HeaderTableViewCell = {
            let cell = tableview.dequeueReusableCell(withIdentifier: "headernib") as! HeaderTableViewCell
            switch inSection[section] {
            case .pickup:
                cell.headerLabel.text = "First header"
                cell.headerBtn.tag = section
                cell.delegate = self
                cell.boolCheck11 = boolCheck1
                cell.boolCheck21 = boolCheck2
            case .deliver:
                cell.headerLabel.text = "Second Header"
                cell.headerBtn.tag = section
                cell.delegate = self
                cell.boolCheck11 = boolCheck1
                cell.boolCheck21 = boolCheck2
            }
            return cell
        }()
        return headerCell
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableview.dequeueReusableCell(withIdentifier: "cellsnib") as? FieldsTableViewCell else {
            fatalError("Thumb Nail Table View Cell Not Found")
        }
        switch inRow[indexPath.row] {
        case .address:
            cell.fieldsTableView.text = "Row1"
        case .email:
            cell.fieldsTableView.text = "Row2"
        }
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath)
    }
    
    
}

extension ViewController: takesection {
    func take(sec: Int, bch1: Bool, bch2: Bool) {
        boolCheck1 = bch1
        boolCheck2 = bch2
        tableview.reloadData()
    }
}

