//
//  FieldsTableViewCell.swift
//  colapsabeltable
//
//  Created by Intern on 09/07/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class FieldsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var fieldsTableView: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
