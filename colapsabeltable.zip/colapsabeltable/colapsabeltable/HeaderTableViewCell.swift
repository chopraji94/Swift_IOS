//
//  HeaderTableViewCell.swift
//  colapsabeltable
//
//  Created by Intern on 09/07/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

protocol takesection: class {
    func take(sec:Int,bch1:Bool,bch2:Bool)
}

class HeaderTableViewCell: UITableViewCell {
    
    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var headerBtn: UIButton!
    weak var delegate:takesection?
    var boolCheck11:Bool?
    var boolCheck21:Bool?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func headerBtnAction(_ sender: Any) {
        if headerBtn.tag == 0 {
            delegate?.take(sec: headerBtn.tag,bch1: !boolCheck11!,bch2: boolCheck21!)
        } else {
            delegate?.take(sec: headerBtn.tag,bch1: boolCheck11!,bch2: !boolCheck21!)
        }
    }
    
}
