//
//  ViewController.swift
//  collectionTable
//
//  Created by Pranav Chopra on 19/09/19.
//  Copyright © 2019 Pranav Chopra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view, typically from a nib.
        
        let fieldsNib = UINib(nibName: "TimeTableViewCell" ,bundle: nil)
        tableView.register(fieldsNib, forCellReuseIdentifier: "fieldsnib")
    }


}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 85.0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Days"
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "fieldsnib") as? TimeTableViewCell else {
            fatalError("Thumb Nail Table View Cell Not Found")
        }
        return cell
    }
    
    
}
