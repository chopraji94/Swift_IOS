//
//  TimeTableViewCell.swift
//  collectionTable
//
//  Created by Pranav Chopra on 19/09/19.
//  Copyright © 2019 Pranav Chopra. All rights reserved.
//

import UIKit

class TimeTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    let spacing:CGFloat = 16.0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.delegate = self
        collectionView.dataSource = self
        let headerNib = UINib(nibName: "OnlySlotsCollectionViewCell" ,bundle: nil)
        collectionView.register(headerNib, forCellWithReuseIdentifier: "headernib")
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

extension TimeTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let numberOfItemsPerRow:CGFloat = 5
//        let spacingBetweenCells:CGFloat = 16
//        
//        let totalSpacing = (2 * self.spacing) + ((numberOfItemsPerRow - 1) * spacingBetweenCells) //Amount of total spacing in a row
//        
//        if let collection = self.collectionView{
//            let width = (collection.bounds.width - totalSpacing)/numberOfItemsPerRow
//            return CGSize(width: width, height: width)
//        }else{
//            return CGSize(width: 0, height: 0)
//        }
//    }
    
//    func numberOfSections(in collectionView: UICollectionView) -> Int {
//        return 2
//    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "headernib", for: indexPath) as? OnlySlotsCollectionViewCell else {
            
            fatalError("Thumb Nail Table View Cell Not Found")
            
        }
        return cell
    }
    
    
}
