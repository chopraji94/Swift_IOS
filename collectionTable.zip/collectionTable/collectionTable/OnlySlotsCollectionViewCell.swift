//
//  OnlySlotsCollectionViewCell.swift
//  collectionTable
//
//  Created by Pranav Chopra on 19/09/19.
//  Copyright © 2019 Pranav Chopra. All rights reserved.
//

import UIKit

class OnlySlotsCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
