//
//  SecondViewController.swift
//  QuestionsTask
//
//  Created by Intern on 02/07/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

enum rowsCase {
    case fQuestion
    case sQuestion
    case tQuestion
    case foQuestion
}

class SecondViewController: UIViewController {

    
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var tableView: UITableView!
     let inRow:[rowsCase] = [.fQuestion,.sQuestion,.tQuestion,.foQuestion]
    var pickerData: [String]?
    var arrData: [String] = ["First Question","Second Question","Third Question","Fourth Question"]
    var dupArrData = [String]()
    var BtnIndex:Int?
    var pickerIndex:Int?
     // let toolBar = UIToolbar()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Questions"
        tableView.delegate = self
        tableView.dataSource = self
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        let headerNib = UINib(nibName: "CustomTableViewCell" ,bundle: nil)
        tableView.register(headerNib, forCellReuseIdentifier: "headernib")
        tableView.separatorStyle = .none
        pickerView.isHidden = true
        pickerData = ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5", "Item 6"]
        dupArrData = pickerData!
        //pickerView.inputAccessoryView = toolBar
    }
    
    
    
}

extension SecondViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? CustomTableViewCell else {
            fatalError("Thumb Nail Table View Cell Not Found")
        }
        switch  inRow[indexPath.row] {
        case .fQuestion:
            cell.textLbl.text = arrData[indexPath.row]
            cell.pickerBtn.tag = indexPath.row
            cell.delegate = self
            cell.callback = {(c)->Void in
                self.pickerView.isHidden = false
            }
        case .sQuestion:
            cell.textLbl.text = arrData[indexPath.row]
            cell.pickerBtn.tag = indexPath.row
            cell.delegate = self
            cell.callback = {(c)->Void in
                self.pickerView.isHidden = false
            }
        case .tQuestion:
            cell.textLbl.text = arrData[indexPath.row]
            cell.pickerBtn.tag = indexPath.row
            cell.delegate = self
            cell.callback = {(c)->Void in
                self.pickerView.isHidden = false
            }
        case .foQuestion:
            cell.textLbl.text = arrData[indexPath.row]
            cell.pickerBtn.tag = indexPath.row
            cell.delegate = self
            cell.callback = {(c)->Void in
                self.pickerView.isHidden = false
            }
        }
        cell.selectionStyle = .none
        return cell
    }

    
}

extension SecondViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return dupArrData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return dupArrData[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        let indexPath = IndexPath(row: BtnIndex!, section: 0)
        arrData[BtnIndex!] = dupArrData[row]
        pickerData!.remove(at: row)
        dupArrData = pickerData!
        pickerIndex = row
        pickerView.reloadAllComponents()
        self.tableView.reloadRows(at: [indexPath], with: .fade)
        self.pickerView.isHidden = true
    }
    
    
}


extension SecondViewController: takeTagIndex {
    func IndexTag(index: Int) {
        print(index)
        BtnIndex = index
    }
    
}
