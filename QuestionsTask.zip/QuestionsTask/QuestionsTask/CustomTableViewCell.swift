//
//  CustomTableViewCell.swift
//  QuestionsTask
//
//  Created by Intern on 02/07/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

protocol takeTagIndex: class {
    func IndexTag(index:Int)
}

class CustomTableViewCell: UITableViewCell {
    
    @IBOutlet weak var textLbl: UILabel!
    @IBOutlet weak var pickerBtn: UIButton!
    @IBOutlet weak var textField: UITextField!
    var callback: ((_ a: UITableViewCell)-> Void)?
    var delegate:takeTagIndex?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func pickBtnAction(_ sender: Any) {
//        print(pickerBtn.tag)
        callback?(self)
        delegate?.IndexTag(index: pickerBtn.tag)
    }
    
    
    @IBAction func textFieldText(_ sender: Any) {
        
    }
    
}

