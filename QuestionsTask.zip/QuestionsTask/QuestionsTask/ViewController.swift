//
//  ViewController.swift
//  QuestionsTask
//
//  Created by Intern on 02/07/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nextBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func nextBtnAction(_ sender: Any) {
        if let secondVc = self.storyboard?.instantiateViewController(withIdentifier: "second") as? SecondViewController {
            //secondVc.delegateSecond = self
            //secondVc.selected = true
            self.navigationController?.pushViewController(secondVc , animated: true)
        }
    }
    
}

