//
//  ViewController.swift
//  signUpCustom
//
//  Created by Intern on 09/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

struct SingupData {
    var value: String
    var placeholder: String
    var title: String
}

enum CellType: Int, CaseIterable {
    case header
    case username
    case fullname
    case gender
    case phonenumber
    case dob
    case address
    case submitButton
    
    var keyboardType: UIKeyboardType {
        switch self {
        case .phonenumber:
            return .numberPad
        default:
            return .default
            
        }
    }
}


class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var values: [SingupData] = [SingupData]()
    let datePicker  = UIDatePicker()
    var profileImage: UIImage?
//    let currentDate = Date()
//    var components = DateComponents()
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        values.append(SingupData(value: "", placeholder: "", title: "header"))
        values.append(SingupData(value: "", placeholder: "enter name", title: "Name"))
        values.append(SingupData(value: "", placeholder: "enter full name", title: "Full Name"))
        values.append(SingupData(value: "", placeholder: "select Gender", title: "Gender"))
        values.append(SingupData(value: "", placeholder: "enter phone number", title: "PhoneNo"))
        values.append(SingupData(value: "", placeholder: "select date of birth", title: "DOB"))
        values.append(SingupData(value: "", placeholder: "enter address", title: "Address"))
        values.append(SingupData(value: "", placeholder: "", title: "Submit"))
        
        let headerNib = UINib(nibName: "HeaderTableViewCell", bundle: nil)
        tableView.register(headerNib, forCellReuseIdentifier: "HeaderTableViewCell")
        let customNib = UINib(nibName: "CustomTableViewCell" , bundle: nil)
        tableView.register(customNib, forCellReuseIdentifier: "CustomTableViewCell")
        let buttonNib = UINib(nibName: "ButtonTableViewCell", bundle: nil)
        tableView.register(buttonNib, forCellReuseIdentifier: "ButtonTableViewCell")
        let dateNib = UINib(nibName: "DatePickerTableViewCell", bundle: nil)
        tableView.register(dateNib, forCellReuseIdentifier: "DatePickerTableViewCell")
        let genderNib = UINib(nibName: "GenderTableViewCell", bundle: nil)
        tableView.register(genderNib, forCellReuseIdentifier: "GenderTableViewCell")
    }
    
    fileprivate func showImagePickerController() {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    
}

extension ViewController:  UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickImage = info[.originalImage] as? UIImage
        {
            profileImage = pickImage
        }
        self.tableView.reloadData()
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
}

extension ViewController : UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0{
            return 200.0
        }
        return 150.0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CellType.allCases.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cellType = CellType(rawValue: indexPath.row) else {
            fatalError("Cell type not exist.")
        }
        
        let cellData = values[indexPath.row]
        
        switch cellType {
        case .header:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "HeaderTableViewCell") as? HeaderTableViewCell else {
                fatalError("HeaderTableViewCell Not Load")
            }
            
            cell.callback = {(c)->Void in
                self.showImagePickerController()
            }
            cell.imgView.image = profileImage
            cell.selectionStyle = .none
            return cell
        case .submitButton:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "ButtonTableViewCell") as? ButtonTableViewCell else {
                fatalError("ButtonTableViewCell is Not in Use")
            }
            cell.selectionStyle = .none
            return cell
            
        case .dob:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "DatePickerTableViewCell")  as? DatePickerTableViewCell else {
                fatalError("DatePickerTableViewCell not fixed")
            }
            cell.selectionStyle = .none
            cell.delegate = self
            //datePicker.minimumDate = Calendar.current.date(byAdding: -18, value: -1, to: Date())
            cell.textField.text = cellData.value
            cell.textField.placeholder = cellData.placeholder
            cell.textField.keyboardType = cellType.keyboardType
            return cell
            
        case .gender:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "GenderTableViewCell") as? GenderTableViewCell else {
                fatalError("GenderTableViewCell Not Load")
            }
            cell.selectionStyle = .none
            cell.delegate = self
            
            cell.txt.text = cellData.value
            cell.txt.placeholder =  cellData.placeholder
            cell.txt.keyboardType = cellType.keyboardType
            
            return cell
            
        default:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableViewCell") as? CustomTableViewCell else {
                fatalError("Page Not Load")
            }
            
            cell.selectionStyle = .none
            
            cell.textField.delegate = self
            cell.lable.text = cellData.title
            cell.textField.text = cellData.value
            cell.textField.placeholder =  cellData.placeholder
            cell.textField.keyboardType = cellType.keyboardType
            return cell
        }
      
    }
    
}

extension ViewController : UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        let position = textField.convert(textField.bounds.origin, to: tableView)
        guard let indexpath = tableView.indexPathForRow(at: position) else {
            return
        }
        
        let text = textField.text ?? ""
        
        var cellData = values[indexpath.row]
        cellData.value = text
        values[indexpath.row] = cellData
        
    }
    
}

extension ViewController: GenderTableViewCellDelegate {
    
    func genderDidSelect(gender: String, cell: UITableViewCell) {
        let indexpath = self.tableView.indexPath(for: cell)
        var cellData = values[indexpath!.row]
        cellData.value = gender
        values[indexpath!.row] = cellData
    }
    
}

extension ViewController: DatePiclerTableViewCellDelegate {
    func takeDate(date: String, cell: UITableViewCell) {
        let indexpath = self.tableView.indexPath(for: cell)
        var cellDataHere = values[indexpath!.row]
        cellDataHere.value = date
        values[indexpath!.row] = cellDataHere
    }
    
    
}


