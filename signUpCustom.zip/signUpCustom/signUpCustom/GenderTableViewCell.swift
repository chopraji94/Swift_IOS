//
//  GenderTableViewCell.swift
//  signUpCustom
//
//  Created by Intern on 10/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit



protocol GenderTableViewCellDelegate {
    func genderDidSelect(gender: String, cell: UITableViewCell)
}

class GenderTableViewCell: UITableViewCell,UIPickerViewDataSource, UIPickerViewDelegate{
    var pickerView = UIPickerView()

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return option.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return option[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let value =  option[row]
        txt.text = value
        delegate?.genderDidSelect(gender: value, cell: self)
    }
    
    var delegate : GenderTableViewCellDelegate?

    @IBOutlet weak var txt: UITextField!
    var option = ["Male" , "Female" , "Others"]
    override func awakeFromNib() {
        super.awakeFromNib()
       
        pickerView.delegate = self
        pickerView.dataSource = self
        txt.inputView = pickerView
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    @IBAction func genderSelection(_ sender: UITextField) {
        
    }
}
