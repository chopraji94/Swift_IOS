//
//  HeaderTableViewCell.swift
//  signUpCustom
//
//  Created by Intern on 09/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class HeaderTableViewCell: UITableViewCell {

    @IBOutlet weak var buttonClick: UIButton!
    @IBOutlet weak var imgView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    var callback: ((_ a: UITableViewCell)-> Void)?

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

      
    }
    
    @IBAction func uploadPicture(_ sender: Any) {
        callback?(self)
    }
}
