//
//  DatePickerTableViewCell.swift
//  signUpCustom
//
//  Created by Intern on 10/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

protocol DatePiclerTableViewCellDelegate {
    func takeDate(date:String, cell: UITableViewCell)
}

class DatePickerTableViewCell: UITableViewCell {
    @IBOutlet weak var textField: UITextField!
    var delegate:DatePiclerTableViewCellDelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
  
    @objc func datePickerChanged(datePicker:UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = DateFormatter.Style.medium
        dateFormatter.timeStyle = DateFormatter.Style.none
        let datePicked = dateFormatter.string(from: datePicker.date)
        textField.text = datePicked
        delegate?.takeDate(date: datePicked, cell: self)
    }
    
    @IBAction func data(_ sender: Any) {
        var component = DateComponents()
        let datePickerView:UIDatePicker = UIDatePicker()
        component.year = -10
        datePickerView.datePickerMode = UIDatePicker.Mode.date
        let calendar: Calendar = Calendar(identifier: Calendar.Identifier.gregorian)
        component.calendar = calendar
        let maxDate: Date = calendar.date(byAdding: component, to: Date())!
        datePickerView.maximumDate = maxDate
        component.year = -60
        let minDate: Date = calendar.date(byAdding: component, to: Date())!
        datePickerView.maximumDate = minDate
        (sender as! UITextField).inputView = datePickerView
        datePickerView.addTarget(self, action: #selector(datePickerChanged), for: UIControl.Event.valueChanged)
    }
    
}
