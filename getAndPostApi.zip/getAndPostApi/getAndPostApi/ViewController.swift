//
//  ViewController.swift
//  getAndPostApi
//
//  Created by Intern on 12/07/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
//    https://www.esa.int/var/esa/storage/images/esa_multimedia/images/2018/03/italy_and_mediterranean/17402074-1-eng-GB/Italy_and_Mediterranean_node_full_image_2.jpg
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let imageUrl  = URL(string: "https://www.esa.int/var/esa/storage/images/esa_multimedia/images/2018/03/italy_and_mediterranean/17402074-1-eng-GB/Italy_and_Mediterranean_node_full_image_2.jpg")!
        let task = URLSession.shared.dataTask(with: imageUrl) { (data,response,error) in
            if error == nil {
                DispatchQueue.main.async {
                    let loadedImage = UIImage(data: data!)
                    self.imageView.image = loadedImage
                }
            }
            
        }
        task.resume()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

