//
//  SeondCollectionViewCell.swift
//  CollectionTimer
//
//  Created by Intern on 20/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class SeondCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var secondCollectionImage: UIImageView!
}
