//
//  FirstScrollCollectionViewCell.swift
//  CollectionTimer
//
//  Created by Intern on 20/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class FirstScrollCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var firstImage: UIImageView!
}
