//
//  ViewController.swift
//  CollectionTimer
//
//  Created by Intern on 20/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var startBtn: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    


    @IBAction func startBtnAction(_ sender: Any) {
        if let secondVc = self.storyboard?.instantiateViewController(withIdentifier: "second") as? SecondViewController {
            self.navigationController?.pushViewController(secondVc , animated: true)
        }
    }
    
}

