//
//  SecondViewController.swift
//  CollectionTimer
//
//  Created by Intern on 20/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

enum horizontalPic {
    case pic1
    case pic2
    case pic3
}

enum verticalPic {
    case pic1
    case pic2
    case pic3
    case pic4
    case pic5
    case pic6
    case pic7
    case pic8
}

enum ScrollDrirection {
    case left
    case right
}
class SecondViewController: UIViewController {

    @IBOutlet weak var firstCollection: UICollectionView!

    @IBOutlet weak var secondCollection: UICollectionView!
    var images:[horizontalPic] = [.pic1, .pic2, .pic3]
    var images2:[verticalPic] = [.pic1, .pic2, .pic3, .pic4, .pic5, .pic6, .pic7, .pic8]
    var cellWidth:CGFloat?
    var countingTimer = Timer()
    var indexPath1: IndexPath?
    var currentIndex = 0
    var isFrowardDirection = true
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Album"
        collectionViewDelegateSetup()
        setupCollectionViewAttributes()
        timerCall()
        task()
        firstCollection.isUserInteractionEnabled = false
    }
    
    deinit {
        print("Dinit called")
    }
   
    
    func check() {
        if isFrowardDirection {
            if currentIndex == images.count-1 {
                currentIndex = currentIndex - 1
                isFrowardDirection = !isFrowardDirection
                return
            }
            currentIndex = currentIndex + 1
            
        } else {
            if currentIndex == 0 {
                currentIndex = currentIndex + 1
                isFrowardDirection = !isFrowardDirection
                return
            }
            currentIndex = currentIndex - 1
            
        }
       
    }

    func setupCollectionViewAttributes() {
        secondCollection.backgroundColor = UIColor.clear
        secondCollection.backgroundView = UIView(frame: CGRect.zero)
    }
    
    func collectionViewDelegateSetup() {
        firstCollection.dataSource = self
        firstCollection.delegate = self
        secondCollection.dataSource = self
        secondCollection.delegate = self
    }
    
    func task() {
        let taskBtn = UIBarButtonItem(title: "Exit", style: .done, target: self, action: #selector(exit))
        self.navigationItem.rightBarButtonItem = taskBtn
    }
    
    @objc func exit() {
        countingTimer.invalidate()
        self.navigationController?.viewControllers.remove(at: 1)
      
    }
    
    func timerCall() {
         self.countingTimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.scrollAutomatically), userInfo: nil, repeats: true)
    }
    
    @objc func scrollAutomatically(_ timer1: Timer) {
        if let coll = firstCollection {
            for _ in 0...currentIndex {
                print("Timer")
                if isFrowardDirection {
                    if currentIndex == images.count-1 {
                        //currentIndex = currentIndex - 1
                        isFrowardDirection = !isFrowardDirection
                        return
                    }
                    currentIndex = currentIndex + 1
                    indexPath1 = IndexPath.init(row: currentIndex, section: 0)
                    coll.scrollToItem(at: indexPath1!, at: .right, animated: true)
                } else {
                    if currentIndex == 0 {
                        //currentIndex = currentIndex + 1
                        isFrowardDirection = !isFrowardDirection
                        return
                    }
                    currentIndex = currentIndex - 1
                    indexPath1 = IndexPath.init(row: currentIndex, section: 0)
                    coll.scrollToItem(at: indexPath1!, at: .left, animated: true)
                }
            }
        }
//        if let coll  = firstCollection {
//            for cell in coll.visibleCells {
//
//                var indexPath: IndexPath? = coll.indexPath(for: cell)
//                if ((indexPath?.row)!  < images.count - 1){
//                    let indexPath1: IndexPath?
//                    indexPath1 = IndexPath.init(row: (indexPath?.row)! + 1, section: (indexPath?.section)!)
//                    coll.scrollToItem(at: indexPath1!, at: .right, animated: true)
//                    //print(indexPath?.row)
//                }
//                else if (indexPath?.row)! == 9{
//                    for i in 1..<images.count {
//                        let indexPath1: IndexPath?
//                        indexPath1 = IndexPath.init(row: (indexPath?.row)!-i, section: (indexPath?.section)!)
//                        coll.scrollToItem(at: indexPath1!, at: .left, animated: true)
//                    }
//                }
//                else {
////                    if (indexPath?.row)!  == 9 {
////                        indexPath = 9
////                    }
////                    if (indexPath?.row)! < 1 {
////                        let indexPath1: IndexPath?
////                        indexPath1 = IndexPath.init(row: 0, section: (indexPath?.section)!)
////                        coll.scrollToItem(at: indexPath1!, at: .left, animated: true)
////                        print("here only 2 \(indexPath?.row)")
////                    }
////                    if (indexPath?.row)!  == 9 {
////                    print("here only \(indexPath?.row)")
////                    var i_count = (indexPath?.row)!
////                    for _ in 0..<images.count {
////                        let indexPath1: IndexPath?
////                         indexPath1 = IndexPath(row: i_count, section: (indexPath?.section)!)
////                         coll.scrollToItem(at: indexPath1!, at: .left, animated: true)
////                        i_count = i_count - 1
////                    }
////                    }
////                    let indexPath1: IndexPath?
////                    indexPath1 = IndexPath.init(row: 0, section: (indexPath?.section)!)
////                    coll.scrollToItem(at: indexPath1!, at: .left, animated: true)
//
//                }
//
//            }
//        }
        
    }
}

extension SecondViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        if collectionView == self.firstCollection {
//            return 10
//        }
//        return 8
        switch collectionView {
        case firstCollection:
            return images.count
        case secondCollection:
            return images2.count
        default:
            return 8
        }
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {

        if collectionView == self.firstCollection {
            let numberOfCell: CGFloat = CGFloat(images.count)
            cellWidth = UIScreen.main.bounds.size.width / numberOfCell
        }
        return CGSize(width: cellWidth!, height: cellWidth!)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.firstCollection {
          let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)  as? FirstScrollCollectionViewCell
            switch images[indexPath.row] {
            case .pic1:
                cell?.firstImage.image = UIImage(named: "Image")
            case .pic2:
                cell?.firstImage.image = UIImage(named: "Image-1")
            case .pic3:
                cell?.firstImage.image = UIImage(named: "Image-2")
            }
            return cell!
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)  as? SeondCollectionViewCell
            switch images2[indexPath.row] {
            case .pic1:
                cell?.secondCollectionImage.image = UIImage(named: "Image-10")
            case .pic2:
                cell?.secondCollectionImage.image = UIImage(named: "Image-11")
            case .pic3:
                cell?.secondCollectionImage.image = UIImage(named: "Image-12")
            case .pic4:
                cell?.secondCollectionImage.image = UIImage(named: "Image-13")
            case .pic5:
                cell?.secondCollectionImage.image = UIImage(named: "Image-14")
            case .pic6:
                cell?.secondCollectionImage.image = UIImage(named: "Image-15")
            case .pic7:
                cell?.secondCollectionImage.image = UIImage(named: "Image-16")
            case .pic8:
                cell?.secondCollectionImage.image = UIImage(named: "Image-17")
            }
            return cell!
        }
        
    }
    
}
