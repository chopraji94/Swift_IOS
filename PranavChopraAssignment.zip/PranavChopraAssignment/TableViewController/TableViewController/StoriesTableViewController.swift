//
//  StoriesTableViewController.swift
//  TableViewController
//
//  Created by Intern on 22/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class StoriesTableViewController: UITableViewController {
    
    var sectionArray = [1,2,3,4]
    var rowArray = [["First","Second","Third","Fourth"],["First","Second","Third","Fourth"],["First","Second","Third","Fourth"],
    ["First","Second","Third","Fourth"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "UITableViewController"
    }

    override func numberOfSections(in tableView: UITableView) -> Int {

        return sectionArray.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return rowArray[section].count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LabelCell", for: indexPath)
        
        cell.textLabel?.text = "\(rowArray[indexPath.section][indexPath.row])"
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "\(sectionArray[section])"
    }
}
