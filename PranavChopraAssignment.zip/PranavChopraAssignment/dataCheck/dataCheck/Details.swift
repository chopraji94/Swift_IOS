//
//  Details.swift
//  dataCheck
//
//  Created by Intern on 23/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import Foundation

class Details {
    
    var firstname:String?
    var middlename:String?
    var lastname:String?
    var dict = [String:Any]()
    
    init(fname: String, mname: String, lname:String) {
        self.firstname = fname
        self.middlename = mname
        self.lastname = lname
        dict["firstname"] = fname
        dict["middlename"] = mname
        dict["lastname"] = lname
        print(dict)
        
    }
}
