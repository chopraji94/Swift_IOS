//
//  DetailsTableViewController.swift
//  dataCheck
//
//  Created by Intern on 23/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class DetailsTableViewController: UITableViewController {

    @IBOutlet var detailsTvc: UITableView!
    var user1: Details?
    var array = ["Personal Info","Address","Company","Vehicle No."]
    var dArray = [["11","12","13","14"],["21","22","23","24"],["31","32","33","34"],["41","42","43","44"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }


    override func numberOfSections(in tableView: UITableView) -> Int {
        return array.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dArray[section].count
    }
     
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LabelCell", for: indexPath)
        
        if indexPath.section == 0
        {
            if indexPath.row == 0 {
                cell.textLabel?.text = user1!.dict["firstname"] as? String
            }
            if indexPath.row == 1 {
                cell.textLabel?.text = user1!.dict["middlename"] as? String
            }
            if indexPath.row == 2 {
                cell.textLabel?.text = user1!.dict["lastname"] as? String
            }
            if indexPath.row == 3 {
                cell.textLabel?.text = user1!.dict["lastname"] as? String
            }
            
        }
        else
        {
            cell.textLabel?.text = "\(dArray[indexPath.section][indexPath.row])"
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "\(array[section])"
    }

}
