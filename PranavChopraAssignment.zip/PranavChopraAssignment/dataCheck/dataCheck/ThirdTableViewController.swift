//
//  ThirdTableViewController.swift
//  dataCheck
//
//  Created by Intern on 23/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ThirdTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }

}
