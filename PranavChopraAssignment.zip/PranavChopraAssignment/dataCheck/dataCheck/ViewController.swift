//
//  ViewController.swift
//  dataCheck
//
//  Created by Intern on 23/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtLabel1: UITextField!
    
    @IBOutlet weak var txtLabel2: UITextField!
    
    @IBOutlet weak var txtLabel3: UITextField!
    
    @IBOutlet weak var btn1: UIButton!
    
    var user : Details?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn1Action(_ sender: Any) {
        
//        if let secondVc = self.storyboard?.instantiateViewController(withIdentifier: "second") as? SecondViewController {
//            user = Details(fname: txtLabel1.text!, mname: txtLabel2.text!, lname: txtLabel3.text!)
//            secondVc.user1 = user
//            self.navigationController?.pushViewController(secondVc, animated:true)
//        }
        if let thirdVc = self.storyboard?.instantiateViewController(withIdentifier: "third") as? DetailsTableViewController {
            user = Details(fname: txtLabel1.text!, mname: txtLabel2.text!, lname: txtLabel3.text!)
            thirdVc.user1 = user
            self.navigationController?.pushViewController(thirdVc, animated:true)
        }

    }
    
}

