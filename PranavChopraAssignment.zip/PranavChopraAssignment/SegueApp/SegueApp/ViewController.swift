//
//  ViewController.swift
//  SegueApp
//
//  Created by Intern on 22/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var drinkDisplaylbl: UILabel!
    @IBOutlet weak var drinkTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let drinkVc = segue.destination as? SecondViewController else {
            return
        }
        drinkVc.drinkValue = drinkTextField.text
    }
    
    @IBAction func didUnwindFromSecondViewController (_ sender: UIStoryboardSegue) {
        guard  let drinkVC = sender.source as? SecondViewController else {
            return
        }
        drinkDisplaylbl.text = drinkVC.takefood.text
    }
}

