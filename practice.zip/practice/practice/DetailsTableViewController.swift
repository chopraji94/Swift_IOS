import UIKit

class DetailsTableViewController: UITableViewController {

    var array = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        if let fruits = getPList(name: "Fruits") {
            for i in fruits {
                array.append(i)
            }
        }
    }

    func getPList(name: String) -> [String]? {
        
        if let path = Bundle.main.path(forResource: name, ofType: "plist") ,
            let xml = FileManager.default.contents(atPath: path) {
            
            return ( try? (PropertyListSerialization.propertyList(from: xml, options: .mutableContainers, format: nil) as? [String])!)
            
        }
        return nil
    }
    

    override func numberOfSections(in tableView: UITableView) -> Int {

        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return array.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LabelCell", for: indexPath)
        
        cell.textLabel?.text = "\(array[indexPath.row])"
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "PLIST ELEMENTS"
    }

}
