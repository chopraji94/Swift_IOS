//
//  ViewController.swift
//  practice
//
//  Created by Intern on 23/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//
//        let cellPhoneObject = CellPhone(name : "IphoneX",price : 100000,operatingSystem : .ios)
//        let encodedData = try? JSONEncoder().encode(cellPhoneObject)
//        print(encodedData)
//        let decodedData = try? JSONDecoder().decode(CellPhone.self, from: encodedData!)
//        print(decodedData)
        
        if let fruits = getPList(name: "Fruits") {
            print(fruits)
        }
        
        
//        let index = 15
//        let b = Name.first
//        let c = Name.second
//        let d = Name.fourth
//        if index == b.rawValue {
//            print("hi")
//        }
//        print(b.rawValue)
//        print(c.rawValue)
//        print(d.rawValue)
        // Do any additional setup after loading the view.
    }

    
    func getPList(name: String) -> [String]? {
        
       if let path = Bundle.main.path(forResource: name, ofType: "plist") ,
        let xml = FileManager.default.contents(atPath: path) {
        
        return ( try? (PropertyListSerialization.propertyList(from: xml, options: .mutableContainers, format: nil) as? [String])!)
        
        }
        return nil
    }
    

}
//enum Name: Int {
//
//    case first = 15
//    case second = 9
//    case fourth
//
//}
//
//struct CellPhone : Codable
//{
//    //String, Double confirm to Codable types.
//    var name : String?
//    var price : Double?
//    //OsType are also Codable types
//    var operatingSystem : OsType?
//    enum CodingKeys : String,CodingKey{
//        case name
//        case price
//        case operatingSystem
//    }
//}
////String confirm to Codable.
//enum OsType  : String, Codable
//{
//    case android
//    case ios
//    case windows
//    case blackberry
//}
