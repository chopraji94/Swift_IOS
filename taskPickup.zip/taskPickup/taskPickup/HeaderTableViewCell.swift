//
//  HeaderTableViewCell.swift
//  taskPickup
//
//  Created by Intern on 17/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

protocol DeleteValues: class {
    func takeButtonTag(tag:Int)
}

class HeaderTableViewCell: UITableViewCell {

    
    @IBOutlet weak var imageForHeader: UIImageView!
    @IBOutlet weak var labelForHeader: UILabel!
    @IBOutlet weak var removeBtn: UIButton!
    weak var delegateDelete:DeleteValues?
    var sectionSwitch:Int?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    @IBAction func removeAction(_ sender: Any) {
        delegateDelete?.takeButtonTag(tag: removeBtn.tag)
    }
    
    
    
}
