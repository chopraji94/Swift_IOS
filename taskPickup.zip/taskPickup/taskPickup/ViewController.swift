//
//  ViewController.swift
//  taskPickup
//
//  Created by Intern on 17/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchField: UITextField!
    @IBOutlet weak var firstTableView: UITableView!
    var array = [Dictionary<String, String>]()
    var dictFiltered = [String:String]()
    var filteredArray = [Dictionary<String, String>]()
    var indexPosition:Int?
    var searchedIndex = [Int]()
    var filter:Bool = false
    let button =  UIButton(type: .custom)
    var index = Dictionary<String, String>()
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.navigationItem.title = "Pickup And Delivery"
        self.firstTableView.isHidden = false
        delegateUse()
        task()
        check()
        editBtn()
        registerNib()
        checkForEditting()
        firstTableView.isEditing = false
        firstTableView.separatorStyle = .none
    }
    
    func checkForEditting() {
        if array.count > 0 {
            
        }
    }
    
    func editBtn() {
        button.frame = CGRect(x: 0, y: 0, width: 100, height: 40)
        button.setTitleColor(.black, for: .normal)
        button.setTitle("Click to Change Row", for: .normal)
        button.addTarget(self, action: #selector(clickOnButton), for: .touchUpInside)
        navigationItem.titleView = button
        button.isEnabled = false
    }
    
    @objc func clickOnButton() {
        if array.count > 0 {
            button.isEnabled = true
            firstTableView.isEditing = true
            print("clicked")
        }
    }
    
    func registerNib() {
        let cellsNib = UINib(nibName: "AllDetailsTableViewCell" ,bundle: nil)
        firstTableView.register(cellsNib, forCellReuseIdentifier: "cellsnib")
    }
    
    func delegateUse() {
        firstTableView.delegate = self
        firstTableView.dataSource = self
    }
    func check() {
        let taskBtn = UIBarButtonItem(title: "Check", style: .done, target: self, action: #selector(listCheck))
        self.navigationItem.leftBarButtonItem = taskBtn
    }
    
    @objc func listCheck() {
        self.view.endEditing(true)
        self.firstTableView.reloadData()
    }
    
    func task() {
        let taskBtn = UIBarButtonItem(title: "+", style: .done, target: self, action: #selector(creatTask))
        firstTableView.isEditing  = false
        self.navigationItem.rightBarButtonItem = taskBtn
    }
    
    @objc func creatTask() {
        if let secondVc = self.storyboard?.instantiateViewController(withIdentifier: "second") as? SecondViewController {
            secondVc.delegateSecond = self
            secondVc.selected = true
            self.navigationController?.pushViewController(secondVc , animated: true)
        }
    }
    
    @IBAction func searchAction(_ sender: Any) {
        
        if filteredArray.count > 0 {
            filteredArray.removeAll()
            searchedIndex.removeAll()
        }
        
        if (searchField.text?.isEmpty)! {
            filter = false
        }
        
//        filteredArray = array.filter({ (dict) -> Bool in
//            return dict["padd"]?.contains(searchField.text ?? "") ?? false
//        })
        for i in 0..<array.count {
            let index = array[i]
            print(array[i])
            if index["padd"] == searchField.text! {
                dictFiltered = index
                filter = true
                filteredArray.append(dictFiltered)
                searchedIndex.append(i)
            }
        }
    }
}

extension ViewController: UITableViewDelegate,UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if filter {
            if filteredArray.count == 0{
                return 0
            }
            return filteredArray.count
        } else {
            if array.count == 0{
                return 0
            }
            return array.count
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = firstTableView.dequeueReusableCell(withIdentifier: "cellsnib") as? AllDetailsTableViewCell else {
            fatalError("Thumb Nail Table View Cell Not Found")
        }
        
        if filter {
            print(indexPath.row)
            index = filteredArray[indexPath.row]
        } else {
            index = array[indexPath.row]
        }
        
        print(index)
        cell.label1.text = "Pickup Address: " + index["padd"]!
        cell.label2.text = "Pickup Number: " + index["pphone"]!
        cell.label3.text = "Pickup Email: " + index["pemail"]!
        cell.label4.text = "Delivey Address: " + index["dadd"]!
        cell.label5.text = "Delivey Number: " + index["dphone"]!
        cell.label6.text = "Delivey Email: " + index["demail"]!
        cell.label40.text = "Insurance: " + index["insurance"]!
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if let secondVc = self.storyboard?.instantiateViewController(withIdentifier: "second") as? SecondViewController {
            secondVc.delegateSecond = self
            if filter {
                secondVc.dictValues = filteredArray[indexPath.row]
                indexPosition = searchedIndex[indexPath.row]
            } else {
                secondVc.dictValues = array[indexPath.row]
                indexPosition = indexPath.row
            }
            
            secondVc.selected = false
            self.navigationController?.pushViewController(secondVc , animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            array.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
        }
    }

    func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let movedObject = self.array[sourceIndexPath.row]
        array.remove(at: sourceIndexPath.row)
        array.insert(movedObject, at: destinationIndexPath.row)
        firstTableView.isEditing = false
        self.firstTableView.reloadData()
    }


}

extension ViewController: SecondDelegate {
    func takeInputs(dict: [String : String], isEditable: Bool) {
        button.isEnabled = true
        if isEditable {
            array[indexPosition!] = dict
            self.searchField.text = ""
            filter = false
            firstTableView.reloadData()
        } else {
            array.append(dict)
            filter  = false
            firstTableView.reloadData()
        }
    }
}
