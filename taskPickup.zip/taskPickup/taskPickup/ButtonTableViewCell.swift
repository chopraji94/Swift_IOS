//
//  ButtonTableViewCell.swift
//  taskPickup
//
//  Created by Intern on 19/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ButtonTableViewCell: UITableViewCell {

    @IBOutlet weak var yesBtn: UIButton!
    @IBOutlet weak var noBtn: UIButton!
    @IBOutlet weak var inTheTextField: UITextField!
    @IBOutlet weak var blackView: UIView!
    
    var callback: ((_ a: UITableViewCell)-> Void)?
    var callback2: ((_ b: UITableViewCell)-> Void)?
    var callback3: ((_ b: UITableViewCell)-> Void)?
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func yesBtnAction(_ sender: Any) {
         callback?(self)
    }
    
    @IBAction func noBtnAction(_ sender: Any) {
        callback2?(self)
    }
    
    
    @IBAction func textAction(_ sender: Any) {
        callback3?(self)
    }
}
