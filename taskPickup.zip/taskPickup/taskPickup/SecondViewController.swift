//
//  SecondViewController.swift
//  taskPickup
//
//  Created by Intern on 17/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

enum sectionHas {
    case pickup
    case deliver
}

enum rowHas {
    case address
    case email
    case phone
    case insurance
}

protocol  SecondDelegate: class {
    func takeInputs(dict: [String:String],isEditable:Bool)
}

class SecondViewController: UIViewController {

    @IBOutlet weak var secondTabelView: UITableView!
    let inRow:[rowHas] = [.address,.email,.phone,.insurance]
    let inSection : [sectionHas] = [.pickup, .deliver]
    var selected:Bool = true
    var insurance_h:CGFloat? = 25
    var dictValues = ["padd": "","pemail": "","pphone": "","dadd": "","demail":"","dphone":"","insurance":""]
    let insuranceName = ["LIC","HSFC","PMYSC"]
    var forInsurance:Bool = true
    weak var delegateSecond:SecondDelegate?
    let rowHeight:CGFloat = 60.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Assign Task"
        secondTabelView.separatorStyle = .none
        delegateUse()
        save()
        registernib()
        checkForHeight()
        secondTabelView.sectionHeaderHeight = UITableView.automaticDimension
        secondTabelView.estimatedSectionHeaderHeight = 500.0
    }
    
    func checkForHeight() {
        if !selected {
            insurance_h! = insurance_h! + 25
        }
    }
    
    func registernib() {
        let cellsNib = UINib(nibName: "FieldsTableViewCell" ,bundle: nil)
        secondTabelView.register(cellsNib, forCellReuseIdentifier: "cellsnib")
        
        let headerNib = UINib(nibName: "HeaderTableViewCell" ,bundle: nil)
        secondTabelView.register(headerNib, forCellReuseIdentifier: "headernib")
        
        let insuranceNib = UINib(nibName: "ButtonTableViewCell" ,bundle: nil)
        secondTabelView.register(insuranceNib, forCellReuseIdentifier: "insurancenib")
    }
    
    func delegateUse() {
        secondTabelView.delegate = self
        secondTabelView.dataSource = self
    }
    
    func save() {
        let saveBtn = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveTask))
        self.navigationItem.rightBarButtonItem = saveBtn
    }
    
    @objc func saveTask() {
         view.endEditing(true)
        if selected {
            delegateSecond?.takeInputs(dict: dictValues,isEditable: false)
        } else {
            delegateSecond?.takeInputs(dict: dictValues,isEditable: true)
        }
        self.navigationController?.popViewController(animated: true)
    }
}

extension SecondViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return inSection.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch  inSection[indexPath.section] {
        case .pickup:
            switch inRow[indexPath.row] {
            case .address:
                return rowHeight
            case .email:
                return rowHeight
            case .phone:
                return rowHeight
            case .insurance:
                return rowHeight+insurance_h!/*rowHeight+50*/
            }
        case .deliver:
            switch inRow[indexPath.row] {
            case .address:
                return rowHeight
            case .email:
                return rowHeight
            case .phone:
                return rowHeight
            case .insurance:
                return 0
            }
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return inRow.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let headerCell: HeaderTableViewCell = {
            let cell = secondTabelView.dequeueReusableCell(withIdentifier: "headernib") as! HeaderTableViewCell
            switch inSection[section] {
            case .pickup:
                cell.labelForHeader.text = "Pickup"
                cell.delegateDelete = self
                cell.removeBtn.tag = section
            case .deliver:
                cell.labelForHeader.text = "Delivery"
                cell.delegateDelete = self
                cell.removeBtn.tag = section
            }
            return cell
        }()
        return headerCell

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = secondTabelView.dequeueReusableCell(withIdentifier: "cellsnib") as? FieldsTableViewCell else {
            fatalError("Thumb Nail Table View Cell Not Found")
        }
        switch inRow[indexPath.row] {
        case .address:
            cell.labels.text = "Enter Address"
            cell.textField.placeholder = "Enter the Address"
            cell.delegate = self
            
            switch inSection[indexPath.section] {
            case .pickup:
                cell.textField.text = dictValues["padd"]
                cell.textField.tag = indexPath.row
                cell.tag = indexPath.section
            case .deliver:
                cell.textField.text = dictValues["dadd"]
                cell.textField.tag = indexPath.row
                cell.tag = indexPath.section
            }
        case .email:
            cell.labels.text = "Enter Email"
            cell.textField.placeholder = "Enter the Email"
            cell.delegate = self
            switch inSection[indexPath.section] {
            case .pickup:
                cell.textField.text = dictValues["pemail"]
                cell.textField.tag = indexPath.row
                cell.tag = indexPath.section
            case .deliver:
                cell.textField.text = dictValues["demail"]
                cell.textField.tag = indexPath.row
                cell.tag = indexPath.section
            }
        case .phone:
            cell.labels.text = "Enter Phone No."
            cell.textField.placeholder = "Enter the Phone Number"
            cell.delegate = self
            
            switch inSection[indexPath.section] {
            case .pickup:
                cell.textField.text = dictValues["pphone"]
                cell.textField.tag = indexPath.row
                cell.tag = indexPath.section
            case .deliver:
                cell.textField.text = dictValues["dphone"]
                cell.textField.tag = indexPath.row
                cell.tag = indexPath.section
            }
        case .insurance:
            guard let cell = secondTabelView.dequeueReusableCell(withIdentifier: "insurancenib") as? ButtonTableViewCell else {
                fatalError("Thumb Nail Table View Cell Not Found")
            }
            if forInsurance == true {
                cell.inTheTextField.isHidden = true
                cell.blackView.isHidden = true
            }
            if !selected {
                cell.inTheTextField.isHidden = false
            }
            switch inSection[indexPath.section] {
            case .pickup:
                cell.callback = {(c)->Void in
                    cell.inTheTextField.isHidden = false
                    cell.blackView.isHidden = false
                    self.forInsurance = false
                    self.insurance_h = 50
                    self.secondTabelView?.beginUpdates()
                    self.secondTabelView.reloadData()
                    self.secondTabelView.endUpdates()
                    
                }
                cell.callback2 = {(c)->Void in
                    cell.inTheTextField.isHidden = true
                    cell.blackView.isHidden = true
                    self.dictValues["insurance"] = "No insurance"
                }
                cell.callback3 = {(c)->Void in
                    let insurancePicker = UIPickerView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 216))
                    insurancePicker.delegate = self
                    insurancePicker.dataSource = self
                    insurancePicker.backgroundColor = .white
                    cell.inTheTextField.inputView = insurancePicker
                }
                cell.inTheTextField.text = self.dictValues["insurance"]
                cell.selectionStyle = .none
                return cell
            case .deliver:
                cell.isHidden = true
            }
        }
        cell.selectionStyle = .none
        return cell
    }
}


extension SecondViewController: takeFieldValues {
    func takeData(value: String, tag: Int, sectionTag: Int) {
        
        switch inSection[sectionTag] {
        case .pickup:
            switch inRow[tag] {
            case .address:
                 dictValues["padd"] = value
            case .email:
                dictValues["pemail"] = value
            case .phone:
                dictValues["pphone"] = value
            case .insurance:
                break
            }
        case .deliver:
            switch inRow[tag] {
            case .address:
                dictValues["dadd"] = value
            case .email:
                dictValues["demail"] = value
            case .phone:
                dictValues["dphone"] = value
            case .insurance :
                break
            }
        }
    }
}

extension SecondViewController: DeleteValues {
    func takeButtonTag(tag: Int) {
        
        switch inSection[tag] {
        case .pickup:
            self.view.endEditing(true)
            dictValues["padd"] = ""
            dictValues["pemail"] = ""
            dictValues["pphone"] = ""
            dictValues["insurance"] = ""
        default:
            self.view.endEditing(true)
            dictValues["dadd"] = ""
            dictValues["demail"] = ""
            dictValues["dphone"] = ""
        }
        secondTabelView.reloadData()
        }
    
}

extension SecondViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return insuranceName.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        return insuranceName[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        self.dictValues["insurance"] = insuranceName[row]
        var indexPath : IndexPath?
        indexPath = IndexPath(row: 3, section: 0)
        secondTabelView.reloadRows(at: [indexPath!], with: .none)
    }
    
}

