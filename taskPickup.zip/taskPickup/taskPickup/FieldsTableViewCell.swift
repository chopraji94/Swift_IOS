//
//  FieldsTableViewCell.swift
//  taskPickup
//
//  Created by Intern on 17/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

protocol  takeFieldValues: class {
    func takeData(value:String,tag:Int,sectionTag:Int)
}

class FieldsTableViewCell: UITableViewCell {

    @IBOutlet weak var labels: UILabel!
    @IBOutlet weak var textField: UITextField!
    weak var delegate:takeFieldValues?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code  
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func textFieldAction(_ sender: Any) {
        delegate?.takeData(value: textField.text!, tag: textField.tag, sectionTag: self.tag)
    }
    
}
