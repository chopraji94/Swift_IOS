//
//  ViewController.swift
//  detailsTask
//
//  Created by Intern on 13/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
        let headerNib1 = UINib(nibName: "FirstTableViewCell" ,bundle: nil)
        tableView.register(headerNib1, forCellReuseIdentifier: "headernib")
        //self.tableView.isHidden = false
        task()
    }
    
    func task() {
        var taskBtn = UIBarButtonItem()
        taskBtn = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(creatTask))
        taskBtn.title = "+"
        self.navigationItem.rightBarButtonItem = taskBtn
    }
    
    @objc func creatTask() {
        if let secondVc = self.storyboard?.instantiateViewController(withIdentifier: "second") as? SecondViewController {            self.navigationController?.pushViewController(secondVc , animated: true)
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? FirstTableViewCell else {
            fatalError("Thumb Nail Table View Cell Not Found")
        }
        
        return cell
    }
    
    
    
}

