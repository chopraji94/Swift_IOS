//
//  SecondViewController.swift
//  detailsTask
//
//  Created by Intern on 13/06/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    
    @IBOutlet weak var secondTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Enter the details"
        
        secondTableView.delegate = self
        secondTableView.dataSource = self
        
        let headerNib = UINib(nibName: "CustomTableViewCell" ,bundle: nil)
        secondTableView.register(headerNib, forCellReuseIdentifier: "headernib")
        // Do any additional setup after loading the view.
    }
    

}

extension SecondViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "headernib") as? CustomTableViewCell else {
            fatalError("Thumb Nail Table View Cell Not Found")
        }
        cell.selectionStyle = .none
        return cell
    }
    
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        let vw = UIView()
//        vw.backgroundColor = UIColor.red
//        return vw
//    }
    
    
}
