//
//  Country.swift
//  APIHandling
//
//  Created by Intern on 14/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import Foundation

class Country {
    
    var name: String = ""
    var code: String = ""
    
    init(with dict: [String: Any]) {
        if let value = dict["name"] as? String {
            self.name = value
        }
        
        if let value = dict["code"] as? String {
            self.code = value
        }
    }
    
    class func countryListFromJsonObject(dictList: [[String: Any]] ) -> [Country] {
        var tempList = [Country]()
        for dict in dictList {
            let country = Country(with: dict)
            tempList.append(country)
        }
        return tempList
    }
    
    class func getCountryList(apiManager: APIManager, urlString: String, callback: @escaping (_ list: [Country]?, _ error: Error?) -> Void) {
    
        apiManager.executeAPI(url: urlString) { (response: [String: Any]?, error: Error?) in
            
            guard let results = response!["results"] as? [[String: Any]] else {
                    callback(nil, nil)
                    return
            }
            
            let countryList = Country.countryListFromJsonObject(dictList: results)
            callback(countryList, nil)
            
        }
        
    }
    
}
