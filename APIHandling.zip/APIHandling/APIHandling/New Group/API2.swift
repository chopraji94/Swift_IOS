//
//  API2.swift
//  APIHandling
//
//  Created by Intern on 14/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import Foundation

class APIManager2 {
    
    func executeAPI(url: String, callback: @escaping (_ data: [String: Any]?, _ error: Error?) -> Void) {
        
        let url = URL(string: url)!
        let session = URLSession(configuration: .default)
        
        let task = session.dataTask(with: url) { (data: Data?, response: URLResponse?, error: Error?) in
            
            
            if let errorIs = error {
                callback(nil, errorIs)
                return
            }
            
            guard let jsonResponse = DataParsing.jsonWith(data: data!) as? [String: Any] else {
                return
            }
            
            callback(jsonResponse, nil)
            
        }
        
        task.resume()
        
    }
    
    
}

class City {
    
    var city: String = ""

    init(with dict: [String: Any]) {
        if let value = dict["city"] as? String {
            self.city = value
        }
        
    }
    
    class func countryListFromJsonObject(dictList: [[String: Any]] ) -> [City] {
        var tempList = [City]()
        for dict in dictList {
            let country = City(with: dict)
            tempList.append(country)
        }
        return tempList
    }
    
    class func getCountryList(apiManager: APIManager2, urlString: String, callback: @escaping (_ list: [City]?, _ error: Error?) -> Void) {
        
        apiManager.executeAPI(url: urlString) { (response: [String: Any]?, error: Error?) in
            
            guard let results = response!["results"] as? [[String: Any]] else {
                callback(nil, nil)
                return
            }
            
            let countryList = City.countryListFromJsonObject(dictList: results)
            callback(countryList, nil)
            
        }
        
    }
    
}


class DataParsing2 {
    
    static func jsonWith(data: Data) -> Any? {
        
        guard let jsonResponse = try? JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) else {
            return nil
        }
        
        return jsonResponse
    }
}
