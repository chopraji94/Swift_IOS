//
//  ViewController.swift
//  APIHandling
//
//  Created by Intern on 14/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var list: [Country]?
    var url2:String? = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        let urlString = "https://api.openaq.org/v1/countries"
        
        let apiManager = APIManager()
        Country.getCountryList(apiManager: apiManager, urlString: urlString) { (list, error) in
            self.list = list
            
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }
        
    }


}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let country = list?[indexPath.row] {
            url2 = "https://api.openaq.org/v1/cities?country=" + country.code
        }
        
        if let goToTable = self.storyboard?.instantiateViewController(withIdentifier: "goToNext") as? SecondViewController {
            self.navigationController?.pushViewController(goToTable, animated: true)
            goToTable.url3 = url2!
        }
        
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "CellId")
        
        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "CellId")
        }
        
        if let country = list?[indexPath.row] {
            cell?.textLabel!.text = "Country name:- \(country.name)"
            cell?.detailTextLabel?.text = "Country Code:- \(country.code)"
            
        }
        
        return cell!
        
    }
}
