//
//  SecondViewController.swift
//  APIHandling
//
//  Created by Intern on 14/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

   
    @IBOutlet weak var secondTableView: UITableView!
    var indicator: UIActivityIndicatorView = UIActivityIndicatorView()
    var list: [City]?
    var url3 = ""
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        indicator.center = self.view.center
        indicator.hidesWhenStopped = true
        indicator.style = .gray
        view.addSubview(indicator)
        indicator.startAnimating()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        secondTableView.delegate = self
        secondTableView.dataSource = self
        
        let urlString = url3
        
        let apiManager = APIManager2()
        City.getCountryList(apiManager: apiManager, urlString: urlString) { (list, error) in
            self.list = list
            
            DispatchQueue.main.async {
                self.secondTableView.reloadData()
            }
            
        }
        
    }
    
    
}

extension SecondViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "CellId")
        
        if cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "CellId")
        }
        
        if let cityName = list?[indexPath.row] {
            cell?.textLabel!.text = "City name:- \(cityName.city)"
            indicator.stopAnimating()
        }
        
        return cell!
        
    }
}
