//
//  ImageCollectionViewCell.swift
//  CollectionView
//
//  Created by Intern on 31/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var picBtn: UIButton!
    
    @IBOutlet weak var crossBtn: UIButton!
    
    var callback: ((_ a: UICollectionViewCell)-> Void)?
    var callback2: ((_ b: UICollectionViewCell)-> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imageView.image = UIImage(named: "Image")
        //callback2?(self)
        // Initialization code
    }
    
    @IBAction func picBtnAction(_ sender: Any) {
        callback?(self)
    }
    
    @IBAction func crossClicked(_ sender: Any) {
        //imageView.image = UIImage(named: "Image")
        callback2?(self)
    }
    
}
