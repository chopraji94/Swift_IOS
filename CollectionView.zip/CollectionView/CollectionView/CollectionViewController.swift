//
//  CollectionViewController.swift
//  CollectionView
//
//  Created by Intern on 30/05/19.
//  Copyright © 2019 Intern. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"



class CollectionViewController: UICollectionViewController {


    
    var cellColor = true
    var sectionCount = 1
    var profileImage: UIImage?
    var imageKey = "galleryImage"
    var editBtn = UIBarButtonItem()
    var saveBtn = UIBarButtonItem()
    var dataArry = [Data]()
    var key:String?
    var data : String?
    var imageNumber:Int?
    var imageArray = [UIImage]()
    var set = false
    //var numberOfItemsInSection = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        save()
        edit()
        getData()
        let headerNib = UINib(nibName: "ImageCollectionViewCell" ,bundle: nil)
        collectionView.register(headerNib, forCellWithReuseIdentifier: "headernib")
        self.navigationItem.title = "Image Galary"
        if imageArray.count == 10 {
            print("Again")
        }
    }
    
    func getData() {
        if let data = UserDefaults.standard.object(forKey: "Data") as? Array<Any>  {
            
            if data.count > 0 {
                print("data count \(data.count)")
                collectionView.reloadData()
            }
        }
    }
    
    func edit()
    {
        editBtn = UIBarButtonItem(title: "Edit", style: .done, target: self, action: #selector(editFunc))
        editBtn.title = "Edit"
        //self.navigationItem.rightBarButtonItem?.isEnabled = false
        self.navigationItem.rightBarButtonItem = editBtn
        editBtn.isEnabled = false
    }
    
    func save()
    {
        saveBtn = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveFunc))
        saveBtn.title = "Save"
        //self.navigationItem.rightBarButtonItem?.isEnabled = false
        self.navigationItem.leftBarButtonItem = saveBtn
        saveBtn.isEnabled = false
    }
    @objc func saveFunc()
    {
       self.editBtn.isEnabled = true
        self.collectionView.allowsSelection = false
            for i in 0..<self.imageArray.count {
                print("i is \(i)")
                let indexPath = IndexPath(row: i, section: 0)
                print("Index path is \(indexPath)")
                let cell = self.collectionView.cellForItem(at: indexPath) as? ImageCollectionViewCell
                cell?.crossBtn.isHidden = true
                self.set = true
                self.collectionView.reloadItems(at: [indexPath])
            }
            self.saveBtn.isEnabled = false
        
            UserDefaults.standard.set(dataArry, forKey: "Data")
        self.getData()
        //self.collectionView.reloadData()
    }
    
    @objc func editFunc()
    {
        self.editBtn.isEnabled = false
        for i in 0..<self.imageArray.count {
            print("i is \(i)")
            let indexPath = IndexPath(row: i, section: 0)
            print("Index path is \(indexPath)")
            let cell = self.collectionView.cellForItem(at: indexPath) as? ImageCollectionViewCell
            cell?.crossBtn.isHidden = true
            self.set = false
            self.collectionView.reloadItems(at: [indexPath])
        }
        self.saveBtn.isEnabled = true
        self.collectionView.allowsSelection = true
    }
    
    func showImagePickerController() {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self
        self.present(imagePicker, animated: true, completion: nil)
        
    }
    
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return sectionCount
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if imageArray.count >= 4 {
            self.saveBtn.isEnabled = true
            return self.imageArray.count
        }
        print(imageArray.count)
        return self.imageArray.count + 1
    }

   
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "headernib", for: indexPath) as? ImageCollectionViewCell else {
                
                fatalError("Thumb Nail Table View Cell Not Found")
                
            }
    
        if saveBtn.isEnabled == true {
            cell.picBtn.isUserInteractionEnabled = false
            cell.isUserInteractionEnabled = false
        }
        
        if self.set == true {
            if indexPath.item == imageArray.count {
                print(indexPath.item)
                cell.imageView.image = UIImage(named: "Image")
                cell.picBtn.isUserInteractionEnabled = true
                cell.isUserInteractionEnabled = true
                cell.crossBtn.isHidden = true
                self.imageNumber = indexPath.item
                cell.callback = {(c)->Void in
                    self.showImagePickerController()
                    cell.crossBtn.isHidden = false
                    //self.loaded = true
                }
                //cell.crossBtn.isHidden = true
            }
            else {
                cell.picBtn.isUserInteractionEnabled = false
                cell.isUserInteractionEnabled = false
                cell.crossBtn.isUserInteractionEnabled = false
                cell.crossBtn.isHidden = true
                cell.imageView.image = self.imageArray[indexPath.item]
            }
            
            print(indexPath.item)
            print(cell.picBtn.isUserInteractionEnabled)
            return cell
        }
        else {
            if indexPath.item == imageArray.count {
                print(indexPath.item)
                cell.imageView.image = UIImage(named: "Image")
                cell.picBtn.isUserInteractionEnabled = true
                cell.isUserInteractionEnabled = true
                cell.crossBtn.isHidden = true
                self.imageNumber = indexPath.item
                cell.callback = {(c)->Void in
                    self.showImagePickerController()
                    cell.crossBtn.isHidden = false
                    //self.loaded = true
                }
                //cell.crossBtn.isHidden = false
            }
            else {
                cell.picBtn.isUserInteractionEnabled = true
                cell.isUserInteractionEnabled = true
                cell.crossBtn.isUserInteractionEnabled = false
                cell.crossBtn.isHidden = false
                cell.imageView.image = self.imageArray[indexPath.item]
            }
            
            print(indexPath.item)
            print(cell.picBtn.isUserInteractionEnabled)
            return cell
        }
        
        // Original
//        if indexPath.item == imageArray.count {
//            print(indexPath.item)
//            cell.imageView.image = UIImage(named: "Image")
//            cell.picBtn.isUserInteractionEnabled = true
//            cell.isUserInteractionEnabled = true
//            cell.crossBtn.isHidden = true
//            self.imageNumber = indexPath.item
//            cell.callback = {(c)->Void in
//                self.showImagePickerController()
//                cell.crossBtn.isHidden = false
//                //self.loaded = true
//            }
//        }
//        else {
//             cell.picBtn.isUserInteractionEnabled = true
//            cell.isUserInteractionEnabled = true
//            cell.crossBtn.isUserInteractionEnabled = false
//            cell.crossBtn.isHidden = false
//            cell.imageView.image = self.imageArray[indexPath.item]
//        }
//
//        print(indexPath.item)
//        print(cell.picBtn.isUserInteractionEnabled)
//        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if imageArray.count > 0 {
            imageArray.remove(at: indexPath[1])
            self.saveBtn.isEnabled = false
            self.collectionView.reloadData()
        }
    }
}

extension CollectionViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        DispatchQueue.main.async {
            if let pickImage = info[.originalImage] as? UIImage
            {
                self.imageArray.append(pickImage)
                let imageData = pickImage.jpegData(compressionQuality: 0.75)
                self.dataArry.append(imageData!)
                UserDefaults.standard.set((imageData), forKey: "Data")
            }
            self.collectionView.reloadData()
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}

